
export interface GeneratedDesign {
  id: string;
  url: string;
  adText: string;
  prompt: string;
  createdAt: Date;
}

export enum DesignStyle {
  MODERN = 'عصري وحديث',
  LUXURY = 'فخم وراقي',
  MINIMALIST = 'بسيط وناعم',
  SUMMER = 'صيفي ومنعش',
  PROFESSIONAL = 'احترافي للاستوديو',
  FUTURISTIC = 'مستقبلي وخيالي'
}

export interface GenerationState {
  isGenerating: boolean;
  error: string | null;
  designs: GeneratedDesign[];
}
