
import React from 'react';

interface ImageUploaderProps {
  onImageSelect: (base64: string) => void;
  selectedImage: string | null;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageSelect, selectedImage }) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageSelect(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-full">
      <label className="block text-zinc-400 mb-2 text-sm font-medium">صورة المنتج</label>
      <div 
        className={`relative border-2 border-dashed rounded-2xl transition-all h-64 flex flex-col items-center justify-center overflow-hidden ${selectedImage ? 'border-purple-500/50 bg-purple-500/5' : 'border-zinc-800 bg-zinc-900/30 hover:bg-zinc-900/50'}`}
      >
        {selectedImage ? (
          <>
            <img src={selectedImage} alt="Product" className="w-full h-full object-contain p-4" />
            <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
              <button 
                onClick={() => onImageSelect('')}
                className="bg-red-500/80 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="p-4 bg-zinc-800 rounded-2xl mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-zinc-500 text-sm mb-1">اسحب الصورة هنا أو اضغط للرفع</p>
            <p className="text-zinc-600 text-xs">يدعم PNG, JPG (يفضل خلفية شفافة)</p>
            <input 
              type="file" 
              accept="image/*" 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              onChange={handleFileChange}
            />
          </>
        )}
      </div>
    </div>
  );
};

export default ImageUploader;
