
import React from 'react';

const Sidebar: React.FC = () => {
  const menuItems = [
    { icon: '🏠', label: 'لوحة القيادة' },
    { icon: '💬', label: 'VoxChat', active: true },
    { icon: '📝', label: 'إنشاء المحتوى' },
    { icon: '🎨', label: 'استوديو مرئي', isOpen: true, subItems: [
      { label: 'صانع الصور', active: true },
      { label: 'استوديو الفيديو', isNew: true },
    ]},
    { icon: '🔊', label: 'الصوت والمقاطع', isNew: true },
    { icon: '📊', label: 'تحليل المحتوى' },
    { icon: '💡', label: 'أدوات الذكاء' },
    { icon: '⚙️', label: 'إدارة النظام' },
  ];

  return (
    <aside className="w-64 bg-[#111112] border-l border-zinc-800 flex flex-col h-screen hidden lg:flex">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center font-bold text-white">V</div>
          <span className="text-xl font-bold tracking-tight text-white">VoxCraft</span>
        </div>

        <nav className="space-y-1">
          {menuItems.map((item, idx) => (
            <div key={idx}>
              <button className={`w-full flex items-center justify-between p-3 rounded-xl transition-colors ${item.active ? 'bg-zinc-800 text-purple-400' : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-white'}`}>
                <div className="flex items-center gap-3">
                  <span className="text-lg">{item.icon}</span>
                  <span className="font-medium">{item.label}</span>
                </div>
                {item.isNew && <span className="bg-rose-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">جديد</span>}
              </button>
              {item.subItems && (
                <div className="mr-8 mt-1 space-y-1 border-r border-zinc-800 pr-2">
                  {item.subItems.map((sub, sIdx) => (
                    <button key={sIdx} className={`w-full text-right p-2 text-sm rounded-lg transition-colors flex items-center justify-between ${sub.active ? 'text-purple-400 font-bold' : 'text-zinc-500 hover:text-zinc-300'}`}>
                      {sub.label}
                      {sub.isNew && <span className="bg-rose-500 text-white text-[10px] px-1.5 py-0.5 rounded-full mr-2">جديد</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-4 border-t border-zinc-800">
        <div className="bg-zinc-900/50 rounded-2xl p-4 border border-zinc-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-zinc-400">Platinum Plan ⚡</span>
          </div>
          <p className="text-[11px] text-zinc-500 mb-3 leading-relaxed">لديك 3/100000 كلمة متبقية في خطتك الشهيرة</p>
          <button className="w-full bg-purple-600 hover:bg-purple-500 text-white py-2 rounded-xl text-sm font-bold transition-all shadow-lg shadow-purple-900/20">
            ترقية
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
