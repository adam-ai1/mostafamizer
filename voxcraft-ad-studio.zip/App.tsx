
import React, { useState, useRef } from 'react';
import ImageUploader from './components/ImageUploader';
import { generateAdDesign } from './services/gemini';
import { DesignStyle, GeneratedDesign } from './types';

const App: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [userPrompt, setUserPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<DesignStyle>(DesignStyle.MODERN);
  const [includeTextOnImage, setIncludeTextOnImage] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [designs, setDesigns] = useState<GeneratedDesign[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!selectedImage) {
      setError('يرجى اختيار صورة أولاً');
      return;
    }

    setIsGenerating(true);
    setError(null);

    try {
      const designCount = 4;
      const generationPromises = Array.from({ length: designCount }).map(() => 
        generateAdDesign(selectedImage, selectedStyle, userPrompt)
      );
      
      const results = await Promise.all(generationPromises);
      
      const newDesigns: GeneratedDesign[] = results.map(res => ({
        id: Math.random().toString(36).substr(2, 9),
        url: res.imageUrl,
        adText: res.adText,
        prompt: userPrompt || selectedStyle,
        createdAt: new Date(),
      }));

      setDesigns(prev => [...newDesigns, ...prev]);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ غير متوقع');
    } finally {
      setIsGenerating(false);
    }
  };

  /**
   * Helper to draw a rounded rectangle on canvas
   */
  const drawRoundedRect = (ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number) => {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();
  };

  /**
   * Function to merge Image and Text onto a single file for download
   */
  const handleDownloadWithText = (url: string, text: string) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.crossOrigin = "anonymous";
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      
      if (!ctx) return;

      // Draw original image
      ctx.drawImage(img, 0, 0);

      if (includeTextOnImage) {
        const padding = canvas.width * 0.05;
        const rectHeight = canvas.height * 0.18;
        const rectWidth = canvas.width * 0.8;
        const rectX = (canvas.width - rectWidth) / 2;
        const rectY = canvas.height * 0.78;
        const radius = 30;

        // Draw adaptive glass plate
        ctx.fillStyle = "rgba(0, 0, 0, 0.45)";
        drawRoundedRect(ctx, rectX, rectY, rectWidth, rectHeight, radius);
        
        // Add subtle highlight border
        ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
        ctx.lineWidth = 2;
        ctx.stroke();

        // Add Arabic Text
        ctx.fillStyle = "white";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.direction = "rtl";
        const baseSize = canvas.width * 0.045;
        const fontSize = text.length > 30 ? baseSize * 0.8 : baseSize;
        ctx.font = `bold ${fontSize}px Tajawal`;
        
        ctx.shadowColor = "rgba(0, 0, 0, 0.5)";
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 4;
        
        ctx.fillText(text, canvas.width / 2, rectY + (rectHeight / 2));
      }

      const link = document.createElement('a');
      link.href = canvas.toDataURL('image/png');
      link.download = `voxcraft-ad-${Date.now()}.png`;
      link.click();
    };
    img.src = url;
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex min-h-screen bg-[#0f0f10] text-zinc-100 overflow-hidden font-['Tajawal']" dir="rtl">
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-zinc-800 flex items-center justify-between px-8 bg-[#0f0f10]/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-rose-400 bg-clip-text text-transparent">VoxCraft استوديو الإعلانات الذكي</h1>
          </div>
          <div className="flex items-center gap-4">
             <div className="px-3 py-1 bg-zinc-800 rounded-full border border-zinc-700">
               <span className="text-xs font-bold text-zinc-400">بواسطة Gemini AI</span>
             </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Control Panel */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-[#18181b] rounded-3xl p-6 border border-zinc-800 shadow-xl">
                <h2 className="text-xl font-bold mb-6 flex items-center gap-3">
                  <span className="w-2 h-8 bg-purple-600 rounded-full"></span>
                  إعدادات الإعلان
                </h2>

                <ImageUploader onImageSelect={setSelectedImage} selectedImage={selectedImage} />

                <div className="mt-6 space-y-4">
                  <div className="flex items-center justify-between p-4 bg-zinc-900 border border-zinc-800 rounded-2xl">
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-zinc-200">عرض النص على التصميم</span>
                      <span className="text-[10px] text-zinc-500 italic">طبقة زجاجية ذكية تبرز الشعار</span>
                    </div>
                    <button 
                      onClick={() => setIncludeTextOnImage(!includeTextOnImage)}
                      className={`w-12 h-6 rounded-full transition-all relative ${includeTextOnImage ? 'bg-purple-600' : 'bg-zinc-700'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${includeTextOnImage ? 'left-1' : 'left-7'}`}></div>
                    </button>
                  </div>

                  <div>
                    <label className="block text-zinc-400 mb-2 text-sm font-medium">النمط البصري</label>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.values(DesignStyle).map((style) => (
                        <button
                          key={style}
                          onClick={() => setSelectedStyle(style)}
                          className={`px-3 py-2 rounded-xl text-xs font-medium transition-all border ${selectedStyle === style ? 'bg-purple-600/20 border-purple-500 text-purple-400' : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:border-zinc-700'}`}
                        >
                          {style}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-zinc-400 mb-2 text-sm font-medium">وصف إضافي للمنتج</label>
                    <textarea 
                      value={userPrompt}
                      onChange={(e) => setUserPrompt(e.target.value)}
                      placeholder="مثال: عطر فاخر في بيئة غابة استوائية هادئة..."
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-purple-600/50 min-h-[100px]"
                    ></textarea>
                  </div>

                  <button 
                    onClick={handleGenerate}
                    disabled={isGenerating || !selectedImage}
                    className={`w-full py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-3 ${isGenerating || !selectedImage ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:scale-[1.02] text-white shadow-lg active:scale-95'}`}
                  >
                    {isGenerating ? (
                      <>
                        <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        جاري التوليد...
                      </>
                    ) : 'توليد 4 تصاميم إحترافية'}
                  </button>
                </div>
              </div>
            </div>

            {/* Results Grid */}
            <div className="lg:col-span-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pb-12">
                {isGenerating && Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="animate-pulse aspect-square bg-zinc-900 border border-zinc-800 rounded-[2.5rem] flex items-center justify-center overflow-hidden">
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-12 h-12 bg-zinc-800 rounded-full"></div>
                      <div className="h-2 w-24 bg-zinc-800 rounded"></div>
                    </div>
                  </div>
                ))}
                
                {designs.length === 0 && !isGenerating && (
                  <div className="col-span-full h-[500px] border-2 border-dashed border-zinc-800 rounded-[2.5rem] flex flex-col items-center justify-center text-center p-8 bg-zinc-900/10">
                    <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center mb-6 text-3xl">🖼️</div>
                    <h3 className="text-xl font-bold text-zinc-500 mb-2">في انتظار إبداعك</h3>
                    <p className="text-zinc-600 max-w-xs">ارفع صورة منتجك وسيقوم الذكاء الاصطناعي بتحويلها لإعلان مبهر بنص عربي سليم.</p>
                  </div>
                )}

                {designs.map((design) => (
                  <div key={design.id} className="group relative flex flex-col bg-[#18181b] rounded-[2.5rem] overflow-hidden border border-zinc-800 shadow-2xl transition-all hover:border-purple-500/50">
                    <div className="relative aspect-square">
                      <img src={design.url} alt="Ad" className="w-full h-full object-cover" />
                      
                      {/* Professional Arabic Text Overlay */}
                      {includeTextOnImage && (
                        <div className="absolute inset-0 flex flex-col justify-end p-6 pointer-events-none">
                          <div className="relative overflow-hidden p-6 rounded-[2rem] bg-black/40 backdrop-blur-md border border-white/10 shadow-2xl">
                            <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent pointer-events-none" />
                            <h3 className="relative text-white text-lg md:text-xl font-extrabold text-center leading-tight drop-shadow-xl">
                              {design.adText}
                            </h3>
                          </div>
                        </div>
                      )}

                      <div className="absolute top-4 left-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button 
                          onClick={() => handleDownloadWithText(design.url, design.adText)}
                          className="bg-white/90 backdrop-blur-sm text-black p-3 rounded-2xl hover:bg-purple-600 hover:text-white transition-all shadow-xl"
                          title="تحميل التصميم"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                        </button>
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <div className="flex items-center justify-between border-t border-zinc-800 pt-4">
                        <button 
                          onClick={() => handleCopyText(design.adText, design.id)}
                          className="text-xs text-zinc-500 hover:text-purple-400 transition-colors flex items-center gap-2"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                          </svg>
                          {copiedId === design.id ? 'تم النسخ!' : 'نسخ النص الإعلاني'}
                        </button>
                        <span className="text-[10px] text-zinc-600 bg-zinc-900 px-2 py-1 rounded-md border border-zinc-800">{design.prompt}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
