
import { GoogleGenAI } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export interface AdResult {
  imageUrl: string;
  adText: string;
}

export const generateAdDesign = async (
  base64Image: string,
  style: string,
  userPrompt: string
): Promise<AdResult> => {
  const ai = getAIClient();
  
  const prompt = `Task: Create a professional high-end advertising background for this product.
  Style: ${style}. 
  Context: ${userPrompt}.
  
  Requirements:
  1. Generate a stunning visual composition where the product is perfectly placed in a matching environment.
  2. The image should NOT contain any text inside the pixels.
  3. Separately, provide a very creative, short, and punchy Arabic slogan (جملة إعلانية) for this product in the text response.
  
  The image result should be high-quality commercial photography.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image.split(',')[1],
            mimeType: 'image/png',
          },
        },
        {
          text: prompt
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  let imageUrl = '';
  let adText = 'أناقة لا تنتهي لمنتجك'; 

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      imageUrl = `data:image/png;base64,${part.inlineData.data}`;
    } else if (part.text) {
      // Extract Arabic text from the response
      const arabicMatch = part.text.match(/[\u0600-\u06FF\s،!؟]+/g);
      if (arabicMatch) {
        adText = arabicMatch[0].trim().split('\n')[0];
      }
    }
  }

  if (!imageUrl) {
    throw new Error("لم يتمكن النظام من توليد الصورة.");
  }

  return { imageUrl, adText };
};
